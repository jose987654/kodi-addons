# Seedr Repository for Kodi

This repository contains the Seedr addon for Kodi.

## Navigation

<pre>
<img src="../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
</pre>

## Installation

1. Download the repository zip file ([repository.seedr-1.0.0.zip](../repository.seedr-1.0.0.zip))
2. In Kodi, go to Add-ons > Install from zip file
3. Select the downloaded zip file
4. The repository will be installed, and you can then install the Seedr addon from the repository

## Available Addons

- **Seedr** - Stream videos, music, and images from your Seedr cloud storage directly to Kodi

## Repository Structure

This repository follows the standard Kodi repository structure:

- `addons.xml` - Contains metadata for all addons in the repository
- `addons.xml.md5` - MD5 hash of the addons.xml file for verification
- `plugin.video.seedr/` - The Seedr addon
- `repository.seedr/` - The repository addon itself
