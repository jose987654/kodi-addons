# Seedr Addon English Language Files

This directory contains English language strings for the Seedr Kodi addon.

## Navigation

<pre>
<img src="../../../../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
</pre>

## Contents

- `strings.po` - English (GB) language translation strings
